# imageprocessingPIL
Project for internship
